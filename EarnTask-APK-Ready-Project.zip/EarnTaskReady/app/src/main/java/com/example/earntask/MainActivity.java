package com.example.earntask;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    int balance = 0;
    SharedPreferences prefs;
    LinearLayout root;
    TextView balanceView;
    int blue = Color.rgb(21,101,192);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("demo", MODE_PRIVATE);
        balance = prefs.getInt("balance", 0);
        buildUI();
    }
    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(4),dp(6),dp(4),dp(6)); return t;
    }
    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(24),dp(20),dp(24)); root.setBackgroundColor(Color.rgb(246,248,252));
        scroll.addView(root); setContentView(scroll);
        TextView title = text("EarnTask", 30, blue); title.setTypeface(null, Typeface.BOLD); root.addView(title);
        root.addView(text("Task tracker • Offline demo", 14, Color.DKGRAY));
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(18),dp(18),dp(18)); card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(18),0,dp(16)); root.addView(card,cp);
        card.addView(text("DEMO BALANCE", 13, Color.GRAY));
        balanceView = text("₹"+balance, 34, Color.rgb(30,100,65)); balanceView.setTypeface(null,Typeface.BOLD); card.addView(balanceView);
        card.addView(text("Demo points only — this app does not generate real money or send UPI payments.", 13, Color.DKGRAY));
        root.addView(text("Practice tasks", 20, Color.BLACK));
        addTask("Read a sample earning-safety tip", 5, "Never pay a registration fee to get a job.");
        addTask("Learn a digital-safety tip", 5, "Never share your UPI PIN or OTP with anyone.");
        addTask("Review a scam warning", 10, "Guaranteed daily income and no-limit withdrawals are common scam claims.");
        Button withdraw = new Button(this); withdraw.setText("UPI withdrawal (demo only)"); root.addView(withdraw);
        withdraw.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Demo only").setMessage("Real UPI withdrawals are not connected. A real app needs a legitimate funded rewards provider, a secure backend, and payment integration.").setPositiveButton("OK", null).show());
        Button reset = new Button(this); reset.setText("Reset demo balance"); root.addView(reset);
        reset.setOnClickListener(v -> { balance=0; prefs.edit().putInt("balance",0).apply(); balanceView.setText("₹0"); Toast.makeText(this,"Demo balance reset",Toast.LENGTH_SHORT).show(); });
    }
    void addTask(String title, int points, String detail) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(8),0,dp(8)); root.addView(card,p);
        TextView name=text(title,17,Color.BLACK); name.setTypeface(null,Typeface.BOLD); card.addView(name);
        card.addView(text(detail,14,Color.DKGRAY));
        Button done=new Button(this); done.setText("Complete • +₹"+points+" demo points"); card.addView(done);
        final boolean[] completed={false};
        done.setOnClickListener(v->{ if(completed[0]) { Toast.makeText(this,"Task already completed",Toast.LENGTH_SHORT).show(); return; } completed[0]=true; balance+=points; prefs.edit().putInt("balance",balance).apply(); balanceView.setText("₹"+balance); done.setText("Completed"); done.setEnabled(false); });
    }
}
